let products = [
    {src: "./image/product.png", name: "Eiusmod mauris torquen", price:"$89.00"},
    {src: "./image/product.png", name: "Eiusmod mauris torquen", price:"$89.00"},
    {src: "./image/product.png", name: "Eiusmod mauris torquen", price:"$89.00"},
    {src: "./image/product.png", name: "Eiusmod mauris torquen", price:"$89.00"},
    {src: "./image/product.png", name: "Eiusmod mauris torquen", price:"$89.00"}
];

products.forEach((item) => {
    let newDiv = document.createElement("div");
    newDiv.setAttribute("class" , "product_cart");
    document.getElementById("products").appendChild(newDiv);
    newDiv.innerHTML = `
    <a href="#">
        <div class="product_cart_img_wrapper">
            <div class="product_cart_img" style="background-image: url(${item.src});"></div>
        </div>
        <div class="product_text">
            <span>${item.name}</span>
            <span>${item.price}</span>    
        </div>
    </a>
    `
})
// --------------------------------------------------------------








// Select all slides
const slides = document.querySelectorAll(".slide");

// loop through slides and set each slides translateX
slides.forEach((slide, indx) => {
  slide.style.transform = `translateX(${indx * 100}%)`;
});

// select next slide button
const nextSlide = document.querySelector(".next");

// current slide counter
let currentSlide = 0;
// maximum number of slides
let numberOfSlides = slides.length - 1;

nextSlide.addEventListener("click", function () {
  // check if current slide is the last and reset current slide
  if (currentSlide === numberOfSlides) {
    currentSlide = 0;
  } else {
    currentSlide++;
  }

  //   move slide by -100%
  slides.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - currentSlide)}%)`;
  });
});

// select next slide button
const prevSlide = document.querySelector(".previous");

// add event listener and navigation functionality
prevSlide.addEventListener("click", function () {
  // check if current slide is the first and reset current slide to last
  if (currentSlide === 0) {
    currentSlide = numberOfSlides;
  } else {
    currentSlide--;
  }

  //   move slide by 100%
  slides.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - currentSlide)}%)`;
  });
});




// --------------------------------------------------------------








// Select all slides
const slidesBlog = document.querySelectorAll(".slideBlog");

// loop through slides and set each slides translateX
slidesBlog.forEach((slide, indx) => {
  slide.style.transform = `translateX(${indx * 100}%)`;
});

// select next slide button
const nextSlideBlog = document.querySelector(".nextBlog");

// current slide counter
let currentSlideBlog = 0;
// maximum number of slides
let numberOfSlidesBlog = slides.length - 1;

nextSlideBlog.addEventListener("click", function () {
  // check if current slide is the last and reset current slide
  if (currentSlideBlog === numberOfSlidesBlog) {
    currentSlideBlog = 0;
  } else {
    currentSlideBlog++;
  }

  //   move slide by -100%
  slidesBlog.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - currentSlideBlog)}%)`;
  });
});

// select next slide button
const prevSlideBlog = document.querySelector(".previousBlog");

// add event listener and navigation functionality
prevSlideBlog.addEventListener("click", function () {
  // check if current slide is the first and reset current slide to last
  if (currentSlideBlog === 0) {
    currentSlideBlog = numberOfSlidesBlog;
  } else {
    currentSlideBlog--;
  }

  //   move slide by 100%
  slidesBlog.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - currentSlideBlog)}%)`;
  });
});
